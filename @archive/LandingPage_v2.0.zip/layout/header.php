<div class="background-circle col-lg-auto col-md-12">
  <img class="img-fluid" src="./images/background-casetonpote-bubble.jpg" alt="background-casetonpote"/>
</div>
<header>
  <div class="container-xl">
    <div class="row justify-content-between align-items-center flex-nowrap">
      <h1 class="col">
        <a href="./index.php" class="logo-img">
          <img src="./images/Logo_case_ton_pote_service_de_rencontre_240-120_light.png" alt="CaseTonPote - l'amité au coeur de l'amour" />
        </a>
      </h1>
    </div>
  </div>
</header>